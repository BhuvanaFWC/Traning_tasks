#include <math.h>

double mid_point(int x1, int x2);
double calculateMedian(double *a, double *b, double *c);
double sqrtApprox(double x);

// Function to calculate the median using custom square root approximation
double calculateMedian(double *a, double *b, double *c) {
    double median;
    // Calculate the median using the formula: sqrt(2*b^2 + 2*c^2 - a^2) / 2
    median = sqrtApprox(2 * (*b) * (*b) + 2 * (*c) * (*c) - (*a) * (*a)) / 2.0;
    return median;
}

// Function to find square root using Newton's method
double sqrtApprox(double x) {
    double result = x;

    // Use Newton's method for better approximation
    for (int i = 0; i < 10; ++i) {
        result = 0.5 * (result + x / result);
    }

    return result;
}


double mid_point(int x1, int x2){
return (x1 + x2)/2;
}

