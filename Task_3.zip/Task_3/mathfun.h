#include <math.h>
double distance(int x1, int y1, int x2, int y2);
double calculateAngle(double a, double b, double c);
double mid_point(int x1, int x2);
double calculateMedian(double *a, double *b, double *c);


double calculateMedian(double *a, double *b, double *c) {
    double median;
    // Calculate the median using the formula: sqrt(2*b^2 + 2*c^2 - a^2) / 2
    median = sqrt(2 * (*b) * (*b) + 2 * (*c) * (*c) - (*a) * (*a)) / 2.0;
    return median;
}
double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

double calculateAngle(double a, double b, double c) {
    return acos((b * b + c * c - a * a) / (2 * b * c));
}

double mid_point(int x1, int x2){
return (x1 + x2)/2;
}

