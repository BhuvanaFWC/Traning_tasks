#include <stdio.h>
#include <math.h>
#include "mathfun.h"

int main() {
    double side_a, side_b, side_c;

    printf("Enter the lengths of the sides of the triangle:\n");
    printf("Side a: ");
    scanf("%lf", &side_a);
    printf("Side b: ");
    scanf("%lf", &side_b);
    printf("Side c: ");
    scanf("%lf", &side_c);

    // Calculate and print the median of the triangle
    double median1 = calculateMedian(&side_a, &side_b, &side_c);
    double median2 = calculateMedian(&side_b, &side_c, &side_a);
    double median3 = calculateMedian(&side_c, &side_a, &side_b);
    printf("The median of the triangle is: %.2lf\n", median1);
        printf("The median of the triangle is: %.2lf\n", median2);
            printf("The median of the triangle is: %.2lf\n", median3);

    return 0;
}

