#include <stdio.h>
#include <math.h>
#include "mathfun.h"

int main() {
    float side_a, side_b, side_c;

    printf("Enter the lengths of the sides of the triangle:\n");
    printf("Side a: ");
    scanf("%f", &side_a);
    printf("Side b: ");
    scanf("%f", &side_b);
    printf("Side c: ");
    scanf("%f", &side_c);

    // Calculate and print the median of the triangle
    float median = calculateMedian(&side_a, &side_b, &side_c);
    printf("The median of the triangle is: %.2f\n", median);

    return 0;
}

