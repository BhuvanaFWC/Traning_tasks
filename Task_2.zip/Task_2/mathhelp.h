double distance(int x1, int y1, int x2, int y2);
double calculateAngle(double a, double b, double c);
double mid_point(int x1, int x2);


double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

double calculateAngle(double a, double b, double c) {
    return acos((b * b + c * c - a * a) / (2 * b * c));
}

double mid_point(int x1, int x2){
return (x1 + x2)/2;
}

