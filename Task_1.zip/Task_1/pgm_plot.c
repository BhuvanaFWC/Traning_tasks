#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define FONT_SIZE 14

// Function to draw a point on the SDL window
void drawPoint(SDL_Renderer* renderer, int x, int y, SDL_Color color) {
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    SDL_RenderDrawPoint(renderer, x, y);
}

// Function to draw a line on the SDL window
void drawLine(SDL_Renderer* renderer, int x1, int y1, int x2, int y2, SDL_Color color) {
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    SDL_RenderDrawLine(renderer, x1, y1, x2, y2);
}

// Function to render text on the SDL window
void renderText(SDL_Renderer* renderer, TTF_Font* font, int x, int y, const char* text, SDL_Color color) {
    SDL_Surface* surface = TTF_RenderText_Solid(font, text, color);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

    SDL_Rect textRect = {x, y, surface->w, surface->h};
    SDL_RenderCopy(renderer, texture, NULL, &textRect);

    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

int main() {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return -1;
    }

    // Initialize SDL_ttf
    if (TTF_Init() < 0) {
        printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        return -1;
    }

    // Load a font
    TTF_Font* font = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", FONT_SIZE);

    if (!font) {
        printf("Failed to load font! SDL_ttf Error: %s\n", TTF_GetError());
        return -1;
    }

    // Create a window and renderer
    SDL_Window* window = SDL_CreateWindow("Triangle and Midpoints", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Triangle vertices with updated coordinates
    int A[] = {100, 300};
    int B[] = {250, 150};
    int C[] = {400, 300};

    // Midpoints
    int D[] = {(B[0] + C[0]) / 2, (B[1] + C[1]) / 2};
    int E[] = {(C[0] + A[0]) / 2, (C[1] + A[1]) / 2};
    int F[] = {(A[0] + B[0]) / 2, (A[1] + B[1]) / 2};

    // Vertex labels
    const char* labelA = "A";
    const char* labelB = "B";
    const char* labelC = "C";
    const char* labelD = "D";
    const char* labelE = "E";
    const char* labelF = "F";

    // Vertex coordinates as strings
    char coordA[20], coordB[20], coordC[20], coordD[20], coordE[20], coordF[20];

    // Convert coordinates to strings
    sprintf(coordA, "(%d, %d)", A[0], A[1]);
    sprintf(coordB, "(%d, %d)", B[0], B[1]);
    sprintf(coordC, "(%d, %d)", C[0], C[1]);
    sprintf(coordD, "(%d, %d)", D[0], D[1]);
    sprintf(coordE, "(%d, %d)", E[0], E[1]);
    sprintf(coordF, "(%d, %d)", F[0], F[1]);

    // Event loop
    int quit = 0;
    SDL_Event e;

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = 1;
            }
        }

        // Clear the renderer
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear(renderer);

        // Draw the triangle
        drawLine(renderer, A[0], A[1], B[0], B[1], (SDL_Color){0, 0, 0, 255});
        drawLine(renderer, B[0], B[1], C[0], C[1], (SDL_Color){0, 0, 0, 255});
        drawLine(renderer, C[0], C[1], A[0], A[1], (SDL_Color){0, 0, 0, 255});

        // Draw the midpoints
        drawPoint(renderer, D[0], D[1], (SDL_Color){255, 0, 0, 255});
        drawPoint(renderer, E[0], E[1], (SDL_Color){255, 0, 0, 255});
        drawPoint(renderer, F[0], F[1], (SDL_Color){255, 0, 0, 255});

        // Draw lines from FD and DE
        drawLine(renderer, F[0], F[1], D[0], D[1], (SDL_Color){0, 0, 0, 255});
        drawLine(renderer, D[0], D[1], E[0], E[1], (SDL_Color){0, 0, 0, 255});

        // Render vertex labels and coordinates
        renderText(renderer, font, A[0] - FONT_SIZE / 2, A[1] - FONT_SIZE / 2, labelA, (SDL_Color){0, 0, 0, 255});
        renderText(renderer, font, B[0] - FONT_SIZE / 2, B[1] - FONT_SIZE / 2, labelB, (SDL_Color){0, 0, 0, 255});
        renderText(renderer, font, C[0] - FONT_SIZE / 2, C[1] - FONT_SIZE / 2, labelC, (SDL_Color){0, 0, 0, 255});
        renderText(renderer, font, D[0] - FONT_SIZE / 2, D[1] - FONT_SIZE / 2, labelD, (SDL_Color){255, 0, 0, 255});
        renderText(renderer, font, E[0] - FONT_SIZE / 2, E[1] - FONT_SIZE / 2, labelE, (SDL_Color){255, 0, 0, 255});
        renderText(renderer, font, F[0] - FONT_SIZE / 2, F[1] - FONT_SIZE / 2, labelF, (SDL_Color){255, 0, 0, 255});

        renderText(renderer, font, A[0] - FONT_SIZE, A[1] + FONT_SIZE / 2, coordA, (SDL_Color){0, 0, 0, 255});
        renderText(renderer, font, B[0] - FONT_SIZE, B[1] + FONT_SIZE / 2, coordB, (SDL_Color){0, 0, 0, 255});
        renderText(renderer, font, C[0] - FONT_SIZE, C[1] + FONT_SIZE / 2, coordC, (SDL_Color){0, 0, 0, 255});
        renderText(renderer, font, D[0] - FONT_SIZE, D[1] + FONT_SIZE / 2, coordD, (SDL_Color){255, 0, 0, 255});
        renderText(renderer, font, E[0] - FONT_SIZE, E[1] + FONT_SIZE / 2, coordE, (SDL_Color){255, 0, 0, 255});
        renderText(renderer, font, F[0] - FONT_SIZE, F[1] + FONT_SIZE / 2, coordF, (SDL_Color){255, 0, 0, 255});

        // Present the renderer
        SDL_RenderPresent(renderer);
    }

    // Destroy window, renderer, and font
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_CloseFont(font);

    // Quit SDL and SDL_ttf
    TTF_Quit();
    SDL_Quit();

    return 0;
}

