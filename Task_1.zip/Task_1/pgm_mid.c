#include<stdio.h>
int main(){
  
// Triangle vertices
    int x1, y1, x2, y2, x3, y3;

    // Input vertices
    printf("Enter coordinates of vertex A (x1 y1): ");
    scanf("%d %d", &x1, &y1);

    printf("Enter coordinates of vertex B (x2 y2): ");
    scanf("%d %d", &x2, &y2);

    printf("Enter coordinates of vertex C (x3 y3): ");
    scanf("%d %d", &x3, &y3);
    // Midpoints
    
    double D[] = {(x1+x2)/2, (y1+y2)/2};
    double E[] = {(x1+x3)/2, (y1+y3)/2};
    double F[] = {(x3+x2)/2, (y3+y2)/2};
    
    printf("Midpoint D--> %lf\t%lf\n",D[0],D[1]);
    printf("Midpoint E--> %lf\t%lf\n",E[0],E[1]);
    printf("Midpoint F--> %lf\t%lf\n",F[0],F[1]);
}
